import 'package:flutter/material.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; 
import 'package:logger/logger.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';

final logger = Logger();

// --- USER TYPE ENUM ---
enum UserType { unknown, professor, student }
// ----------------------

// --- GEOFENCE CONSTANTS (Holy Angel University, Angeles City) ---
const LatLng _campusCenter = LatLng(15.1325, 120.5902);
const double _campusRadiusMeters = 300.0;
//

// 🎯 UPDATED: Comprehensive Building Locations Map with Exact Coordinates for marking
final Map<String, LatLng> _hauBuildings = {
  'sjh': LatLng(15.132822367971235, 120.58922973116563),
  'st. joseph hall': LatLng(15.132822367971235, 120.58922973116563),
  'mgn': LatLng(15.132995508164218, 120.58957234404568),
  'mamerto g nepomuceno': LatLng(15.132995508164218, 120.58957234404568),
  'aps': LatLng(15.131864882012842, 120.59005161409719),
  'archbishop pedro santos': LatLng(15.131864882012842, 120.59005161409719),
  'sh': LatLng(15.131471376911547, 120.58928251808638),
  'sacred heart': LatLng(15.131471376911547, 120.58928251808638),
  'pgn': LatLng(15.13255674084428, 120.59027819012874),
  'pampanga graduates nook': LatLng(15.13255674084428, 120.59027819012874),
  'main': LatLng(15.133302019649191, 120.59007450128203),
  'holy angel main bldg': LatLng(15.133302019649191, 120.59007450128203),
  'chapel': LatLng(15.132227404007507, 120.58952766555232),
  'djdn': LatLng(15.131560036674847, 120.58978399831277),
  'don juan d nepomuceno': LatLng(15.131560036674847, 120.58978399831277),
  'sgh': LatLng(15.132249459419915, 120.59108257697721),
  'smh': LatLng(15.132143015779075, 120.59093739206065),
  'ggn': LatLng(15.131755730287319, 120.59053999366536),
  'geromin g nepomuceno': LatLng(15.131755730287319, 120.59053999366536),
  'sfj': LatLng(15.1325, 120.5900),
  'san francisco de javier': LatLng(15.1325, 120.5900),
};
TileLayer get openStreetMapTileLayer => TileLayer(
  urlTemplate: 'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
  userAgentPackageName: 'dev.leaflet.homePage.example',
);

// 1. SCHEDULE DATA MODEL
class Schedule {
  final String id;
  // 🎯 MODIFIED: Allow this to be nullable since student schedules won't have it
  final String? professorEmail; 
  final String subjectCode;
  final String subjectName;
  final String room;
  final String building;
  final String floor;
  final int dayOfWeek; // 1=Monday, 7=Sunday
  final TimeOfDay startTime;
  final TimeOfDay endTime;

  Schedule({
    required this.id,
    this.professorEmail, // Now optional
    required this.subjectCode,
    required this.subjectName,
    required this.room,
    required this.building,
    required this.floor,
    required this.dayOfWeek,
    required this.startTime,
    required this.endTime,
  });

  factory Schedule.fromJson(Map<String, dynamic> json) {
    TimeOfDay parseTime(String timeString) {
      final parts = timeString.split(':');
      final hour = int.parse(parts[0]);
      final minuteString = parts[1].split('.').first;
      final minute = int.parse(minuteString);
      return TimeOfDay(hour: hour, minute: minute);
    }

    return Schedule(
      id: json['id'] as String? ?? '',
      // Handles both 'professor_email' and 'student_id' tables gracefully
      professorEmail: json['professor_email'] as String?, 
      subjectCode: json['subject_code'] as String? ?? 'N/A',
      subjectName: json['subject_name'] as String? ?? 'N/A',
      room: json['room'] as String? ?? 'N/A',
      building: json['building'] as String? ?? 'N/A',
      floor: json['floor'] as String? ?? 'N/A',
      dayOfWeek: json['day_of_week'] as int? ?? 0,
      startTime: parseTime(json['start_time'] as String? ?? '00:00:00'),
      endTime: parseTime(json['end_time'] as String? ?? '00:00:00'),
    );
  }
}

// 2. PROFESSOR DATA MODEL (No changes needed here)
class Professor {
  final String name;
  final String email;
  final String? currentRoom;
  final String? currentBuilding;

  Professor({
    required this.name,
    required this.email,
    this.currentRoom,
    this.currentBuilding,
  });

  factory Professor.fromJson(Map<String, dynamic> json) {
    return Professor(
      name: json['name'] ?? 'Unknown',
      email: json['email'] ?? 'No email',
      currentRoom: json['current_room'] as String?,
      currentBuilding: json['current_building'] as String?,
    );
  }
}

class HomePagee extends StatefulWidget {
  const HomePagee({super.key});
  @override
  State<HomePagee> createState() => _HomePageState();
}

class _HomePageState extends State<HomePagee> {
  // NEW STATE VARIABLES
  UserType _userType = UserType.unknown; // 🎯 NEW: Track user type
  // 🎯 FIX: Store the current user's name, initialized to loading state.
  String? _currentUserName = 'Loading...'; 
  StreamSubscription<Position>? _positionStreamSubscription;
  Position? _currentPosition;
  bool _isServiceEnabled = true;
  bool _isTracking = false;

  late final RealtimeChannel _professorsChannel;

  List<Schedule> userSchedule = [];
  Schedule? nextClass;
  bool _isLoadingSchedule = true;

  LatLng? _searchedBuildingLocation;
  final TextEditingController _searchController = TextEditingController();

  int? selectedProfIndex;
  static const double navButtonClosed = 130.0;
  double navButton = navButtonClosed;
  static const double navnextRoomButtonClosed = 65.0;
  double navnextRoomButton = navnextRoomButtonClosed;
  // 🎯 MODIFIED: Initial selectedIndex=0 to show 'All Professors' or custom panel
  int selectedIndex = 6; 
  final PanelController panelController = PanelController();

  final supabase = Supabase.instance.client;
  List<Professor> professors = [];
  String? currentUserEmail;

  @override
  void initState() {
    super.initState();
    currentUserEmail = supabase.auth.currentUser?.email;
    logger.i('Current user email: $currentUserEmail');

    // 🎯 MODIFIED: Check user type, then fetch data based on role
    _checkUserType().then((_) {
      if (_userType == UserType.professor) {
        _fetchProfessorSchedule(); // Professor schedule
        _checkAndStartLocationTracking();
      } else if (_userType == UserType.student) {
        _fetchStudentSchedule(); // Student schedule
      } else {
        setState(() {
          _isLoadingSchedule = false; 
        });
      }
      
      // Both user types need the professors list and realtime updates
      _setupRealtimeChannel();
      fetchProfessors();
    });
  }

  @override
  void dispose() {
    _positionStreamSubscription?.cancel();
    _searchController.dispose();
    supabase.removeChannel(_professorsChannel);
    super.dispose();
  }

  // 🎯 FIX: Modified to fetch the user's name and store it robustly
  Future<void> _checkUserType() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      setState(() {
        _currentUserName = 'Error: Not Logged In';
      });
      return;
    }
    
    // Default to error state
    String? fetchedName = 'Error Loading';

    // Check 'professors' table
    final profs = await supabase
        .from('professors')
        .select('id, name') 
        .eq('user_id', userId)
        .limit(1);

    if (profs.isNotEmpty) {
      fetchedName = profs.first['name'] as String?;
      setState(() {
        _userType = UserType.professor;
      });
      logger.i('User identified as: PROFESSOR');
    } else {
      // Check 'students' table
      final students = await supabase
          .from('students')
          .select('id, name') 
          .eq('user_id', userId)
          .limit(1);

      if (students.isNotEmpty) {
        fetchedName = students.first['name'] as String?;
        setState(() {
          _userType = UserType.student;
        });
        logger.i('User identified as: STUDENT');
      } else {
        setState(() => _userType = UserType.unknown);
        logger.i('User identified as: UNKNOWN');
      }
    }
    
    // 🎯 FINAL NAME ASSIGNMENT LOGIC
    setState(() {
      // If the name is null or empty, provide a specific error message
      _currentUserName = (fetchedName?.isNotEmpty == true && fetchedName != 'Error Loading')
          ? fetchedName
          : 'Error Loading Name (Check DB)'; 
    });
  }

  void _setupRealtimeChannel() {
    _professorsChannel = supabase.channel('professors_location');

    _professorsChannel
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'professors',
          callback: (payload) {
            logger.i('Realtime update received: ${payload.runtimeType}');
            fetchProfessors();
          },
        )
        .subscribe();

    logger.i('Subscribed to Realtime changes on professors table.');
  }

  void _searchAndMarkBuilding(String query) {
    final normalizedQuery = query.toLowerCase().trim();
    LatLng? locationFound;

    if (normalizedQuery.isNotEmpty) {
      final foundEntry = _hauBuildings.entries.firstWhere(
        (entry) =>
            entry.key == normalizedQuery || entry.key.contains(normalizedQuery),
        orElse: () => MapEntry('', LatLng(0, 0)),
      );

      if (foundEntry.key.isNotEmpty) {
        locationFound = foundEntry.value;
      }
    }

    setState(() {
      _searchedBuildingLocation = locationFound;
      if (_searchedBuildingLocation != null) {
        logger.i(
            'Building found and marked: $query at $_searchedBuildingLocation');
      }
    });
  }

  // 🎯 RENAMED: Old Professor schedule fetch
  Future<void> _fetchProfessorSchedule() async {
    if (_userType != UserType.professor || currentUserEmail == null) {
      setState(() {
        _isLoadingSchedule = false;
      });
      return;
    }

    try {
      final response = await supabase
          .from('schedules') // 👈 Fetches from Professor Schedules
          .select()
          .eq('professor_email', currentUserEmail!);

      setState(() {
        userSchedule = (response as List)
            .map((e) => Schedule.fromJson(e as Map<String, dynamic>))
            .toList();
        nextClass = _getClassStatus(userSchedule);
        _isLoadingSchedule = false;
      });
    } catch (e) {
      logger.e('Error fetching professor schedule: $e');
      setState(() {
        _isLoadingSchedule = false;
      });
    }
  }

  // 🎯 NEW: Student schedule fetch function
  Future<void> _fetchStudentSchedule() async {
    final userId = supabase.auth.currentUser?.id;
    if (_userType != UserType.student || userId == null) {
      setState(() {
        _isLoadingSchedule = false;
      });
      return;
    }

    try {
      final response = await supabase
          .from('student_schedules') // 👈 Fetches from Student Schedules
          .select()
          .eq('student_id', userId); // 👈 Filters by student_id (auth.uid())

      setState(() {
        userSchedule = (response as List)
            .map((e) => Schedule.fromJson(e as Map<String, dynamic>))
            .toList();
        nextClass = _getClassStatus(userSchedule);
        _isLoadingSchedule = false;
      });
    } catch (e) {
      logger.e('Error fetching student schedule: $e');
      setState(() {
        _isLoadingSchedule = false;
      });
    }
  }

  Schedule? _getClassStatus(List<Schedule> schedule) {
    if (schedule.isEmpty) return null;

    final now = DateTime.now();
    final currentDay = now.weekday;
    final currentTimeInMinutes = now.hour * 60 + now.minute;

    final todaySchedule =
        schedule.where((c) => c.dayOfWeek == currentDay).toList();

    Schedule? closestNextClass;
    int minMinutesUntilStart = 999999;

    for (final classEntry in todaySchedule) {
      final classStartTimeInMinutes =
          classEntry.startTime.hour * 60 + classEntry.startTime.minute;
      final classEndTimeInMinutes =
          classEntry.endTime.hour * 60 + classEntry.endTime.minute;

      if (currentTimeInMinutes >= classStartTimeInMinutes &&
          currentTimeInMinutes <= classEndTimeInMinutes) {
        return classEntry;
      }

      if (classStartTimeInMinutes > currentTimeInMinutes) {
        final minutesUntilStart = classStartTimeInMinutes - currentTimeInMinutes;

        if (minutesUntilStart < minMinutesUntilStart) {
          minMinutesUntilStart = minutesUntilStart;
          closestNextClass = classEntry;
        }
      }
    }

    return closestNextClass;
  }

  void _stopLocationTracking() {
    _positionStreamSubscription?.cancel();
    _positionStreamSubscription = null;
    if (mounted) {
      setState(() {
        _currentPosition = null;
        _isTracking = false;
      });
    }
    logger.i('Location tracking stopped.');
  }

  // 🎯 NEW: Function to clear professor location in the database (off-campus or no class)
  Future<void> _clearProfessorLocation() async {
    if (_userType != UserType.professor || currentUserEmail == null) return;

    try {
      await supabase
          .from('professors')
          .update({
            'current_room': null,
            'current_building': null,
          })
          .eq('email', currentUserEmail!);
      logger.i('Professor location cleared in DB (Off-campus or no class).');
    } catch (e) {
      logger.e('Error clearing professor location: $e');
    }
  }

  // 🎯 NEW: Function to update professor location in the database (on-campus)
  Future<void> _updateProfessorLocation() async {
    if (_userType != UserType.professor || currentUserEmail == null) return;

    final currentOrNextClass = nextClass; // Use the state variable

    if (currentOrNextClass != null) {
      try {
        await supabase
            .from('professors')
            .update({
              'current_room': currentOrNextClass.room,
              'current_building': currentOrNextClass.building,
            })
            .eq('email', currentUserEmail!);
        logger.i(
            'Professor location updated in DB: ${currentOrNextClass.room} in ${currentOrNextClass.building}.');
      } catch (e) {
        logger.e('Error updating professor location: $e');
      }
    } else {
      // On campus but no class. Clear location fields in DB.
      _clearProfessorLocation();
    }
  }

  bool _isInsideCampus(Position position) {
    double distanceInMeters = Geolocator.distanceBetween(
      _campusCenter.latitude,
      _campusCenter.longitude,
      position.latitude,
      position.longitude,
    );
    return distanceInMeters <= _campusRadiusMeters;
  }

  Future<void> _checkAndStartLocationTracking() async {
    // 🎯 Only start tracking if the user is a Professor
    if (_userType != UserType.professor) {
      logger.i('User is a Student. Location tracking skipped.');
      return;
    }
    
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      _stopLocationTracking();
      // 🎯 MODIFIED: Clear DB location when service is disabled
      _clearProfessorLocation();
      if (mounted) {
        setState(() => _isServiceEnabled = false);
        // Show Dialog/Alert
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Location Services Required'),
              content: const Text(
                'Please turn on your phone\'s Location Services (GPS) to use the tracking and campus features.',
              ),
              actions: <Widget>[
                TextButton(
                  child: const Text('OK'),
                  onPressed: () => Navigator.of(context).pop(),
                ),
                TextButton(
                  child: const Text('Open Settings'),
                  onPressed: () async {
                    Navigator.of(context).pop();
                    await Geolocator.openLocationSettings();
                  },
                ),
              ],
            );
          },
        );
      }
      return;
    }

    if (mounted && !_isServiceEnabled) {
      setState(() => _isServiceEnabled = true);
    }

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _stopLocationTracking();
        // 🎯 MODIFIED: Clear DB location when permission is denied
        _clearProfessorLocation();
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      _stopLocationTracking();
      // 🎯 MODIFIED: Clear DB location when permission is denied
      _clearProfessorLocation();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: const Text(
                'Location permission is permanently denied. Please enable it manually in your phone settings to track your location.'),
            backgroundColor: Colors.red.shade700,
            duration: const Duration(seconds: 4)));
      }
      return;
    }

    _startLocationUpdates();
  }
  
  void _startLocationUpdates() {
    _positionStreamSubscription?.cancel();

    const locationSettings = LocationSettings(
      accuracy: LocationAccuracy.bestForNavigation,
      distanceFilter: 10,
    );

    _positionStreamSubscription =
        Geolocator.getPositionStream(
      locationSettings: locationSettings,
    ).listen((Position position) {
      final bool inside = _isInsideCampus(position);

      if (inside) {
        if (_positionStreamSubscription?.isPaused == true) {
          _positionStreamSubscription?.resume();
        }
        if (mounted) {
          setState(() {
            _currentPosition = position;
            _isTracking = true;
          });
        }
        // 🎯 NEW: Update professor's location in the database
        _updateProfessorLocation();
      } else {
        _positionStreamSubscription?.pause();
        if (mounted) {
          setState(() {
            _currentPosition = null;
            _isTracking = false;
          });
        }
        // 🎯 NEW: Clear professor's location in the database
        _clearProfessorLocation();
        logger.w('Outside Campus. Tracking paused.');
      }
    }, onError: (error) {
      logger.e('Location stream error: $error');
      _stopLocationTracking();
      _clearProfessorLocation(); // Clear DB location on error
      _checkAndStartLocationTracking();
    });

    logger.i('Location stream listener started.');
  }

  void _showUserLocationStatus() {
    String message;
    Color backgroundColor;

    if (_userType == UserType.student) {
      message = 'You are a Student. Location tracking is disabled.';
      backgroundColor = Colors.grey.shade700;
    } else if (_isTracking && _currentPosition != null) {
      message = 'You are currently **INSIDE** the campus!';
      backgroundColor = Colors.green.shade700;
    } else if (_isServiceEnabled) {
      message = 'Out of campus. Location tracking is **paused**.';
      backgroundColor = Colors.red.shade700;
    } else {
      message = 'Location Service Disabled. Enable GPS to use tracking.';
      backgroundColor = Colors.orange.shade700;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: backgroundColor,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void openPanel(int index) {
    double pos = panelController.panelPosition;

    if (selectedIndex == index) {
      if (pos == 0.0) {
        panelController.animatePanelToPosition(0.5, curve: Curves.easeInOut);
      } else {
        panelController.close();
      }
    } else {
      setState(() {
        selectedIndex = index;
      });

      if (pos == 0.0) {
        panelController.animatePanelToPosition(0.5, curve: Curves.easeInOut);
      }
    }
  }

  Widget topBar() {
    // The tracking indicator now shows green only for tracking professors
    Color indicatorColor = _userType == UserType.professor && _isTracking
        ? Colors.green.shade600
        : Colors.red.shade600;

    if (_userType == UserType.student) {
      indicatorColor = Colors.grey.shade600; // Grey for non-tracking students
    }

    return Container(
      padding: const EdgeInsets.all(10),
      child: Container(
        height: 50,
        width: double.maxFinite,
        padding: const EdgeInsets.only(top: 5, left: 5, right: 1, bottom: 5),
        decoration: const BoxDecoration(
          color: Color(0xFF550000),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(5),
            bottomLeft: Radius.circular(30),
            bottomRight: Radius.circular(30),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            // Tracking Status Indicator
            Container(
              margin: const EdgeInsets.only(left: 8, right: 8),
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: indicatorColor,
              ),
            ),
            Expanded(
              child: Container(
                height: 50,
                margin: const EdgeInsets.only(right: 5),
                alignment: Alignment.center,
                child: TextField(
                  controller: _searchController,
                  textAlign: TextAlign.left,
                  style: const TextStyle(fontSize: 12),
                  onSubmitted: (value) {
                    _searchAndMarkBuilding(value);
                    FocusScope.of(context).unfocus();
                  },
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    hintText: 'Search building (e.g., SJH, PGN)',
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.clear, size: 18),
                      onPressed: () {
                        _searchController.clear();
                        _searchAndMarkBuilding('');
                        FocusScope.of(context).unfocus();
                      },
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    border: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                  ),
                ),
              ),
            ),
            // 🎯 NEW: Profile Button
            Container(
              alignment: Alignment.center,
              width: 40,
              height: 40,
              margin: const EdgeInsets.only(right: 5),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: GestureDetector(
                  onTap: () => openPanel(0), // Open the new profile panel
                  child: const Icon(
                    Icons.person,
                    size: 25,
                    color: Color(0xFF550000),
                  ),
                ),
              ),
            ),
            // Location Status Button
            Container(
              alignment: Alignment.center,
              width: 40,
              height: 40,
              margin: const EdgeInsets.only(right: 5),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: GestureDetector(
                  onTap: _showUserLocationStatus,
                  child: const Icon(
                    Icons.location_on,
                    size: 25,
                    color: Color(0xFFEFBF04),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget building() {
    return Align(
      alignment: Alignment.topLeft,
      child: Container(
        height: 150,
        width: 70,
        decoration: const BoxDecoration(
          color: Color(0xFF550000),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(3),
            bottomLeft: Radius.circular(15),
            bottomRight: Radius.circular(15),
          ),
        ),
        margin: const EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12),
                  topRight: Radius.circular(1),
                  bottomLeft: Radius.circular(12),
                  bottomRight: Radius.circular(12),
                ),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(1);
                },
                child: const Text(
                  'SJH',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(2);
                },
                child: const Text(
                  'MGN',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(3);
                },
                child: const Text(
                  'APS',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🎯 MODIFIED: navNextRoom - Show for BOTH Student and Professor
  Widget navNextRoom() {
    // Now visible for students!
    if (_userType == UserType.unknown) return const SizedBox.shrink();

    return FloatingActionButton.extended(
      backgroundColor: Colors.white,
      onPressed: () {
        openPanel(4);
      },
      label: Text(
        // Change label based on user type
        _userType == UserType.professor ? 'Navigate next class' : 'My Schedule',
        style: const TextStyle(
          fontWeight: FontWeight.w900,
          color: Color(0xFFEFBF04),
          fontSize: 15,
        ),
      ),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(5),
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
    );
  }

  LatLng? _getBuildingLocation(String buildingName) {
    final normalizedName = buildingName.toLowerCase().trim();
    final found = _hauBuildings.keys.firstWhere(
      (key) => normalizedName.contains(key) || key.contains(normalizedName),
      orElse: () => '',
    );

    return found.isNotEmpty ? _hauBuildings[found] : null;
  }

  Future<void> fetchProfessors() async {
    try {
      final response = await supabase.from('professors').select();

      setState(() {
        professors = (response as List)
            .map((p) => Professor.fromJson(p as Map<String, dynamic>))
            .where(
              // Filter out the current user ONLY if they are a professor
              (professor) => 
                _userType == UserType.professor ? professor.email != currentUserEmail : true,
            )
            .map((prof) {
              return Professor(
                name: prof.name,
                email: prof.email,
                currentRoom: prof.currentRoom,
                currentBuilding: prof.currentBuilding,
              );
            }).toList();
      });

      logger.i(
        'Professors loaded: ${professors.length}. User Type: $_userType',
      );
    } catch (e) {
      logger.e('Error fetching professors: $e');
    }
  }

  Widget mapWidget() {
    const LatLng center = _campusCenter;
    final List<Marker> markers = [];

    // 1. Searched Building Marker
    if (_searchedBuildingLocation != null) {
      markers.add(
        Marker(
          width: 80.0,
          height: 80.0,
          point: _searchedBuildingLocation!,
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color:
                      Colors.blue.shade800,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: const Icon(
                  Icons.search,
                  color: Colors.white,
                  size: 20.0,
                ),
              ),
              Icon(
                Icons.arrow_drop_down,
                color: Colors.blue.shade800,
                size: 20,
              ),
            ],
          ),
        ),
      );
    }

    // 2. User Marker (Only for tracking Professors)
    if (_userType == UserType.professor && _currentPosition != null) {
      markers.add(
        Marker(
          width: 80.0,
          height: 80.0,
          point: LatLng(
            _currentPosition!.latitude,
            _currentPosition!.longitude,
          ),
          child: const Icon(
            Icons.person_pin_circle,
            color: Colors.blue,
            size: 40.0,
          ),
        ),
      );
    }

    // 3. Next/Current Class Building Marker (For BOTH Professor and Student)
    if (nextClass != null) {
      final targetLocation = _getBuildingLocation(nextClass!.building);

      if (targetLocation != null) {
        final isCurrentClass = _getClassStatus(userSchedule) == nextClass;

        markers.add(
          Marker(
            width: 80.0,
            height: 80.0,
            point: targetLocation,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: isCurrentClass
                        ? Colors.green.shade800
                        : const Color(0xFF550000),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                  child: Icon(
                    // Different icon for student schedule
                    _userType == UserType.student ? Icons.book : Icons.class_sharp,
                    color: const Color(0xFFEFBF04),
                    size: 20.0,
                  ),
                ),
                Icon(
                  Icons.arrow_drop_down,
                  color: isCurrentClass
                      ? Colors.green.shade800
                      : const Color(0xFF550000),
                  size: 20,
                ),
              ],
            ),
          ),
        );
      }
    }

    // 4. Professor Location Markers
    // Show professor pins if viewer is a student OR an on-campus professor
    final bool currentUserCanViewProfLocation =
        _userType == UserType.student || (_userType == UserType.professor && _currentPosition != null);

    for (final prof in professors) {
      final profLocation = prof.currentBuilding != null
          ? _getBuildingLocation(prof.currentBuilding!)
          : null;

      if (profLocation != null && currentUserCanViewProfLocation) {
        markers.add(
          Marker(
            width: 100.0,
            height: 100.0,
            point: profLocation,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black, width: 1),
                  ),
                  child: Text(
                    prof.name.split(' ').first,
                    style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF550000)),
                  ),
                ),
                Icon(
                  Icons.school,
                  color: Colors.orange.shade700,
                  size: 25.0,
                ),
                Icon(
                  Icons.arrow_drop_down,
                  color: Colors.orange.shade700,
                  size: 15,
                ),
              ],
            ),
          ),
        );
      }
    }

    return FlutterMap(
      options: const MapOptions(
        initialCenter: center,
        initialZoom: 17.5,
        maxZoom: 19.0,
        minZoom: 16.0,
        interactionOptions:
            InteractionOptions(flags: InteractiveFlag.none),
      ),
      children: [
        openStreetMapTileLayer,
        CircleLayer(
          circles: [
            CircleMarker(
              point: _campusCenter,
              radius: _campusRadiusMeters,
              color: const Color(0xFF550000).withOpacity(0.1),
              borderColor: const Color(0xFF550000),
              borderStrokeWidth: 1.0,
            ),
          ],
        ),
        MarkerLayer(markers: markers),
      ],
    );
  }

  Widget content() {
    return mapWidget();
  }

  Widget prof(BuildContext context) {
    if (professors.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: Center(
          child: Text(
            'No professors found in the database.',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
        ),
      );
    }

    // 🎯 MODIFIED: Use the same logic as the map to determine visibility
    final bool currentUserCanViewProfLocation =
        _userType == UserType.student || (_userType == UserType.professor && _currentPosition != null);


    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: professors.length,
      itemBuilder: (context, index) {
        final prof = professors[index];
        final bool profIsTracking = prof.currentRoom != null && prof.currentBuilding != null;

        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  prof.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    color: Color(0xFF550000),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  prof.email,
                  style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                ),
                // List view summary logic: Only show summary if viewer has permission
                if (currentUserCanViewProfLocation)
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: Text(
                      profIsTracking
                          ? 'Current Location: ${prof.currentRoom} (${prof.currentBuilding})'
                          : 'Location Status: Off-Campus / Not Tracking',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: profIsTracking ? Colors.green.shade700 : Colors.red.shade700,
                      ),
                    ),
                  )
                else
                  const Padding(
                    padding: EdgeInsets.only(top: 4.0),
                    child: Text(
                      'Professor status is hidden due to your location.',
                      style: TextStyle(
                        fontStyle: FontStyle.italic,
                        color: Colors.red,
                      ),
                    ),
                  ),
              ],
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            onTap: () {
              setState(() {
                selectedProfIndex = index;
                selectedIndex = 5;
              });
            },
          ),
        );
      },
    );
  }

  // ... (sjh, mgn, aps are all UNCHANGED) ...
  Widget sjh() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              color: Colors.transparent,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/joseph_hall.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(left: 30),
            child: const Text(
              'St. Joseph Hall Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            color: const Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: const Alignment(0, 0),
            child: const Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(margin: const EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  Widget mgn() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/mgn.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(left: 30),
            child: const Text(
              'Mamerto G. Nepomuceno Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            color: const Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: const Alignment(0, 0),
            child: const Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(margin: const EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  Widget aps() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/aps.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(left: 30),
            child: const Text(
              'Archbisop Pedro Sanros Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            color: const Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: const Alignment(0, 0),
            child: const Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(margin: const EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  // 🎯 MODIFIED: navNextRoompanel - Now handles BOTH student and professor schedules
  Widget navNextRoompanel() {
    if (_userType == UserType.unknown) {
      return const Center(child: Padding(
        padding: EdgeInsets.all(40.0),
        child: Text("Identifying user type...", style: TextStyle(fontSize: 18, color: Colors.grey)),
      ));
    }

    if (_isLoadingSchedule) {
      return const Center(
          child: Padding(
        padding: EdgeInsets.all(40.0),
        child: CircularProgressIndicator(),
      ));
    }

    if (userSchedule.isEmpty) {
       return Center(
        child: Padding(
          padding: const EdgeInsets.all(40.0),
          child: Text(
            _userType == UserType.student
                ? 'Your student schedule is empty. Please add classes to the student_schedules table.'
                : 'No classes found in your professor schedule.',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: Color(0xFF550000),
            ),
          ),
        ),
      );
    }

    final currentClass = _getClassStatus(userSchedule);

    if (currentClass == null) {
      return Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.all(40),
        child: Text(
          _userType == UserType.student 
            ? '🎉 No current or next classes for today! Enjoy your break.'
            : '🎉 No more classes scheduled for today! Enjoy your break.',
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w900,
            color: Color(0xFF550000),
          ),
        ),
      );
    }

    final now = DateTime.now();
    final currentTimeInMinutes = now.hour * 60 + now.minute;
    final classStartTimeInMinutes =
        currentClass.startTime.hour * 60 + currentClass.startTime.minute;

    final isCurrentClass = currentTimeInMinutes >= classStartTimeInMinutes;

    final startTimeFormatted = MaterialLocalizations.of(context).formatTimeOfDay(
      currentClass.startTime,
      alwaysUse24HourFormat: false,
    );
    final endTimeFormatted = MaterialLocalizations.of(context).formatTimeOfDay(
      currentClass.endTime,
      alwaysUse24HourFormat: false,
    );

    final dayOfWeekNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    final dayName = dayOfWeekNames[currentClass.dayOfWeek - 1];

    String buildingAsset;
    final buildingName = currentClass.building;

    if (buildingName.contains('St. Joseph Hall')) {
      buildingAsset = 'assets/images/joseph_hall.jpg';
    } else if (buildingName.contains('Mamerto G. Nepomuceno')) {
      buildingAsset = 'assets/images/mgn.jpg';
    } else if (buildingName.contains('Archbisop Pedro Sanros')) {
      buildingAsset = 'assets/images/aps.jpg';
    } else {
      buildingAsset = 'assets/images/placeholder.png';
    }
    
    // Determine the main title for the panel
    String mainTitle;
    if (_userType == UserType.student) {
        mainTitle = isCurrentClass ? 'CURRENT CLASS' : 'NEXT CLASS';
    } else {
        mainTitle = isCurrentClass ? 'CURRENT CLASS IN SESSION' : 'NEXT CLASS UPCOMING';
    }


    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: isCurrentClass
                ? Colors.green.shade800
                : const Color(0xFF550000),
            height: 50,
            width: double.infinity,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.only(left: 10),
            child: Text(
              mainTitle,
              style: const TextStyle(
                fontSize: 22,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),

          const SizedBox(height: 20),

          Text(
            '${currentClass.subjectCode}: ${currentClass.subjectName}',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w900,
              color: Color(0xFF550000),
            ),
          ),
          const SizedBox(height: 10),

          Text(
            '📅 $dayName | ⏰ $startTimeFormatted - $endTimeFormatted',
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 15),

          const Text(
            'Location:',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: Color(0xFF550000),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Building: ${currentClass.building}',
                  style: const TextStyle(fontSize: 18),
                ),
                Text(
                  'Floor: ${currentClass.floor}',
                  style: const TextStyle(fontSize: 18),
                ),
                Text(
                  'Room: ${currentClass.room}',
                  style: const TextStyle(fontSize: 18),
                ),
              ],
            ),
          ),

          Container(
            margin: const EdgeInsets.only(top: 20, bottom: 20),
            width: double.infinity,
            height: 180,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.grey.shade400, width: 2),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                buildingAsset,
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: Colors.grey[300],
                    alignment: Alignment.center,
                    child: const Text(
                      'Image for Building Not Available',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey, fontSize: 16),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ... (navProfpanel is UNCHANGED) ...
  Widget navProfpanel(int index) {
    final prof = professors[index];

    // Check the TARGET professor's tracking status
    final bool profIsTracking = prof.currentRoom != null && prof.currentBuilding != null;

    String locationTitle;
    Widget locationContent;

    if (profIsTracking) {
      locationTitle = 'CURRENT LOCATION';
      locationContent = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Building: ${prof.currentBuilding}',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.normal),
          ),
          Text(
            'Room: ${prof.currentRoom}',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.normal),
          ),
        ],
      );
    } else {
      locationTitle = 'LOCATION STATUS';
      locationContent = const Text(
        'This professor is currently **Off-Campus** or **Not Tracking**. Location details are unavailable.',
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.normal,
          color: Colors.red,
        ),
      );
    }

    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: const Color(0xFF550000),
            height: 60,
            width: double.infinity,
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Professor ${prof.name}',
                  style: const TextStyle(
                    fontSize: 20,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  prof.email,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(40, 30, 40, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  locationTitle,
                  textAlign: TextAlign.left,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF550000),
                  ),
                ),
                const SizedBox(height: 15),
                Center(child: locationContent),
              ],
            ),
          ),
          // Placeholder map/image area - only relevant if tracking
          if (profIsTracking)
            Container(
              margin: const EdgeInsets.only(top: 20, bottom: 20),
              decoration: const BoxDecoration(
                color: Color.fromARGB(255, 119, 119, 119),
              ),
              width: double.infinity,
              height: 150,
              alignment: Alignment.center,
              child: Image.asset(
                'assets/images/myimage.png',
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: Colors.grey[300],
                    alignment: Alignment.center,
                    child: Text(
                      'Building Map for ${prof.currentBuilding ?? 'N/A'}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.grey, fontSize: 16),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
  
  // 🎯 NEW: Widget to display the current user's profile
  Widget _buildMyProfilePanel() {
    final String userName = _currentUserName ?? 'Error Loading';
    final String userEmail = currentUserEmail ?? 'No Email Found';
    final String userTypeDisplay = 
        _userType == UserType.professor ? 'Professor' : 
        _userType == UserType.student ? 'Student' : 'Unknown';

    return Padding(
      padding: const EdgeInsets.all(40.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'MY PROFILE',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w900,
              color: Color(0xFF550000),
            ),
          ),
          const SizedBox(height: 30),
          Center(
            child: Column(
              children: [
                const Icon(Icons.person_pin, size: 80, color: Color(0xFFEFBF04)),
                const SizedBox(height: 20),
                // 🎯 FIX: Display the fetched name
                Text(
                  userName,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 8),
                // Display the email, which the user confirmed is working
                Text(
                  userEmail,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.grey.shade700,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF550000),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'Role: $userTypeDisplay',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  Widget panelContent() {
    if (_userType == UserType.unknown) {
       return const Center(
          child: Padding(
            padding: EdgeInsets.all(40.0),
            child: Column(
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 20),
                Text('Identifying user type...', style: TextStyle(fontSize: 16)),
              ],
            ),
          ),
        );
    }
    
    // 🎯 Only show the location service warning to the Professor
    if (_userType == UserType.professor && !_isServiceEnabled) {
      return Padding(
        padding: const EdgeInsets.all(40.0),
        child: Column(
          children: [
            const Text(
              '⚠️ Location Service Disabled',
              style: TextStyle(
                color: Color(0xFF550000),
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 15),
            Text(
              'Please enable your phone\'s **Location Services (GPS)** to use the full range of campus features like tracking and professor location visibility.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontStyle: FontStyle.italic,
                color: Colors.red.shade700,
              ),
            ),
            const SizedBox(height: 15),
            ElevatedButton.icon(
              onPressed: () => Geolocator.openLocationSettings(),
              icon: const Icon(Icons.settings),
              label: const Text('Open Location Settings'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFEFBF04),
                foregroundColor: const Color(0xFF550000),
              ),
            ),
          ],
        ),
      );
    }

    Widget mainContent;

    switch (selectedIndex) {
      case 0: // 🎯 NEW: Profile case
        mainContent = _buildMyProfilePanel();
        break;
      case 1:
        mainContent = sjh();
        break;
      case 2:
        mainContent = mgn();
        break;
      case 3:
        mainContent = aps();
        break;
      case 4:
        mainContent = navNextRoompanel();
        break;
      case 5:
        if (!panelController.isPanelOpen) {
          panelController.animatePanelToPosition(0.5);
        }
        int index = selectedProfIndex ?? 0;
        if (professors.isNotEmpty && index < professors.length) {
          mainContent = navProfpanel(index);
        } else {
          mainContent = const Center(
            child: Text('Professor data not available.'),
          );
        }
        break;
      case 6: // Default case for Professor list
      default:
        mainContent = Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 5),
              child: Text(
                _userType == UserType.student ? 'ALL PROFESSORS' : 'OTHER PROFESSORS',
                style: const TextStyle(
                  fontSize: 20,
                  color: Color(0xFF550000),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Container(margin: const EdgeInsets.all(20), child: prof(context)),
          ],
        );
        break;
    }

    return mainContent;
  }

  Widget buildNavButton(BuildContext context) {
    if (_userType == UserType.student) return const SizedBox.shrink();

    return FloatingActionButton(
      backgroundColor: Colors.white,
      child: const Icon(Icons.my_location, color: Color(0xFFEFBF04)),
      onPressed: () {
        _checkAndStartLocationTracking();
      },
    );
  }

  Widget toggleButton() {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        Container(
          alignment: Alignment.center,
          width: double.maxFinite,
          height: 30,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            color: Color(0xFF550000),
          ),
        ),
        Container(
          alignment: Alignment.center,
          margin: const EdgeInsets.all(10),
          width: 50,
          height: 5,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: const Color(0xFFEFBF04),
          ),
        ),
      ],
    );
  }

  final ScrollController _controller = ScrollController();

  Widget panelWidget() {
    return Column(
      children: [
        toggleButton(),
        Expanded(
          child: ListView(
            padding: EdgeInsets.zero,
            controller: _controller,
            children: <Widget>[panelContent(), const SizedBox(height: 60)],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    double panelHeightOpen = 620;
    final panelHeightClosed = MediaQuery.of(context).size.height * 0;

    return Scaffold(
      body: Stack(
        alignment: Alignment.topCenter,
        children: <Widget>[
          content(),
          Stack(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [topBar(), building()],
                ),
              ),
            ],
          ),
          SlidingUpPanel(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
            controller: panelController,
            maxHeight: panelHeightOpen,
            minHeight: panelHeightClosed,
            panelBuilder: (ScrollController sc) {
              return Column(
                children: [
                  toggleButton(),
                  Expanded(
                    child: ListView(
                      padding: EdgeInsets.zero,
                      controller: sc,
                      children: <Widget>[
                        panelContent(),
                        const SizedBox(height: 60)
                      ],
                    ),
                  ),
                ],
              );
            },
            snapPoint: 0.5,
            onPanelSlide: (position) => setState(() {
              double panelMaxScrollExtent = panelHeightOpen;
              navButton =
                  navButtonClosed + (panelMaxScrollExtent - 50) * position;
              navnextRoomButton = navnextRoomButtonClosed +
                  (panelMaxScrollExtent - 50) * position;
            }),
          ),
          Positioned(
            bottom: navButton,
            right: 20,
            // 🎯 FIX: Removed redundant Column wrapper for button visibility glitch
            child: buildNavButton(context), 
          ),
          Positioned(
            bottom: navnextRoomButton,
            right: 20,
            // 🎯 FIX: Removed redundant Column wrapper for button visibility glitch
            child: navNextRoom(), 
          ),
        ],
      ),
    );
  }
}