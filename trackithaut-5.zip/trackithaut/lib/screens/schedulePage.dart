import 'package:flutter/material.dart';
// import 'package:stroke_text/stroke_text.dart'; // REMOVED: No longer needed after removing PROFESSOR text
import 'package:flutter_timetable/flutter_timetable.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; 
import 'package:logger/logger.dart';
// 1. SCHEDULE DATA MODEL
final logger = Logger();
// Defines the structure for a single schedule entry from the Supabase 'schedules' table.
class Schedule {
  final String id;
  final String professorEmail;
  final String subjectCode;
  final String subjectName;
  final String room;
  final String building;
  final String floor;
  final int dayOfWeek; // 1=Monday, 7=Sunday
  final TimeOfDay startTime;
  final TimeOfDay endTime;

  Schedule({
    required this.id,
    required this.professorEmail,
    required this.subjectCode,
    required this.subjectName,
    required this.room,
    required this.building,
    required this.floor,
    required this.dayOfWeek,
    required this.startTime,
    required this.endTime,
  });

  factory Schedule.fromJson(Map<String, dynamic> json) {
    TimeOfDay parseTime(String timeString) {
      final parts = timeString.split(':');
      final hour = int.parse(parts[0]);
      // Safely handle the minute part, ignoring any milliseconds (e.g., '30.000000')
      final minute = int.parse(parts[1].split('.').first); 
      return TimeOfDay(hour: hour, minute: minute);
    }

    return Schedule(
      id: json['id'].toString(), 
      professorEmail: json['professor_id']['email'] as String,
      subjectCode: json['subject_code'] as String,
      subjectName: json['subject_name'] as String,
      room: json['room'] as String,
      building: json['building'] as String, 
      floor: json['floor'] as String,
      dayOfWeek: json['day_of_week'] as int,
      startTime: parseTime(json['start_time'] as String),
      endTime: parseTime(json['end_time'] as String),
    );
  }
}

class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key});

  @override
  State<SchedulePage> createState() => _SchedulePage();
}

class _SchedulePage extends State<SchedulePage> {
  final TimetableController _controller = TimetableController(
    startHour: 6,
    endHour: 21,
    cellHeight: 100, 
    initialColumns: 7, 
  );

  List<Schedule> _schedules = [];
  bool _isLoading = true;
  String? _error;
  // REMOVED: _professorEmail is no longer used for display or internal logic after filtering is applied
  // String? _professorEmail; 

  @override
  void initState() {
    super.initState();
    _fetchSchedules(); 
  }
  
  Future<void> _fetchSchedules() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    final currentUserEmail = Supabase.instance.client.auth.currentUser?.email;
    
    // REMOVED: setState(() { _professorEmail = currentUserEmail; });
    // The email is used immediately for filtering instead of being stored as state.

    if (currentUserEmail == null) {
      // Handle unauthenticated users
      setState(() {
        _error = 'Please log in to view your specific schedule.';
        _schedules = [];
        _isLoading = false;
      });
      return;
    }

try {
    final response = await Supabase.instance.client
        .from('schedules')
        // 💡 FIX: Join 'schedules' with 'professors' (aliased as professor_id) to select the email
        .select('*, professor_id!inner(email)') 
        // 💡 FIX: Filter the schedules by the email in the joined professors table
        .eq('professor_id.email', currentUserEmail) 
        .order('day_of_week')
        .order('start_time');
    
    final schedules = (response as List<dynamic>)
        .map((json) => Schedule.fromJson(json as Map<String, dynamic>))
        .toList();

      setState(() {
        _schedules = schedules;
        _isLoading = false;
      });
    } on PostgrestException catch (e) {
      setState(() {
        _error = 'Database Error: ${e.message}';
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'An unexpected error occurred: $e';
        _isLoading = false;
      });
    }
  }

  Widget topBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 1)),
      ),
      child: Container(
        margin: const EdgeInsets.all(10),
        alignment: Alignment.center,
        child: const Text(
          'Schedule',
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 25,
            fontWeight: FontWeight.w300,
          ),
        ),
      ),
    );
  }
  
  // Cleaned up header: Only "Work Schedule" remains.
  Widget grlvl() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start, 
      children: [
        Text(
          'Work Schedule',
          style: TextStyle(
            color: Colors.black,
            fontSize: 25,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget timetable() {
    if (_isLoading) {
      return const Center(child: Padding(
        padding: EdgeInsets.only(top: 50.0),
        child: CircularProgressIndicator(color: Color(0xFF550000)),
      ));
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            _error!,
            style: const TextStyle(color: Colors.red),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    
    // Show a message if the list is empty after loading
    if (_schedules.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.only(top: 50.0),
          child: Text(
            'No schedules found for this professor.',
            style: TextStyle(
              fontSize: 18, 
              color: Color(0xFF550000), 
              fontWeight: FontWeight.w500
            ),
          ),
        ),
      );
    }


    final baseDate = DateTime(2025, 10, 13); 

    List<TimetableItem<Schedule>> timetableItems = _schedules.map((schedule) {
      final dayOffset = schedule.dayOfWeek - 1; 
      final startDay = baseDate.add(Duration(days: dayOffset));
      
      final startDateTime = DateTime(
        startDay.year, startDay.month, startDay.day,
        schedule.startTime.hour, schedule.startTime.minute,
      );

      final endDateTime = DateTime(
        startDay.year, startDay.month, startDay.day, 
        schedule.endTime.hour, schedule.endTime.minute,
      );

      return TimetableItem<Schedule>(
        startDateTime,
        endDateTime,
        data: schedule,
      );
    }).toList();
    
    // We remove the NotificationListener that blocked horizontal scroll
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade400),
      ),
      height: MediaQuery.of(context).size.height * 0.7, 
      // Wrap the Timetable in a SingleChildScrollView for horizontal scrolling
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal, 
        child: SizedBox(
          // Set a fixed, wide width (e.g., 900) to ensure each column is wider
          width: 900, 
          child: Timetable<Schedule>(
            controller: _controller,
            items: timetableItems,
            
            itemBuilder: (item) {
              final schedule = item.data!;
              final String start =
                  '${item.start.hour.toString().padLeft(2, '0')}:${item.start.minute.toString().padLeft(2, '0')}';
              final String end =
                  '${item.end.hour.toString().padLeft(2, '0')}:${item.end.minute.toString().padLeft(2, '0')}';

              return Container(
                margin: const EdgeInsets.symmetric(vertical: 1, horizontal: 1), 
                padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 4), 
                decoration: BoxDecoration(
                  color: const Color(0xFFEFBF04), // Yellow background
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: Colors.black, width: 0.5),
                ),
                child: SingleChildScrollView( 
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      // Subject Code
                      Text(
                        schedule.subjectCode, 
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF550000)), // Increased font back up
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1, 
                      ),
                      // Subject Name (Increased maxLines for better wrapping)
                      Text(
                        schedule.subjectName,
                        style: const TextStyle(
                            fontWeight: FontWeight.normal, fontSize: 11, color: Color(0xFF550000)), // Increased font back up
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2, 
                      ),
                      // Room
                      Text(
                        '${schedule.room} (${schedule.building}/${schedule.floor})',
                        style: const TextStyle(fontSize: 10, color: Color(0xFF550000)), // Increased font back up
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                      // Time 
                      Text(
                        '$start - $end',
                        style: const TextStyle(fontSize: 9, color: Color(0xFF550000)), // Increased font back up
                        maxLines: 1,
                      ),
                    ],
                  ),
                ),
              );
            },
            
            // Header builder (Mon, Tue, etc.)
            headerCellBuilder: (dateTime) {
              const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
              return Center(
                child: Text(
                  days[dateTime.weekday - 1],
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13, // Increased font back up
                    color: Color(0xFF550000)
                  ),
                ),
              );
            },
            // Hour label builder (7 AM, 8 AM, etc.)
            hourLabelBuilder: (time) {
              final hour = time.hour == 12 ? 12 : time.hour % 12;
              final period = time.hour < 12 ? 'AM' : 'PM';
              return Text(
                '$hour $period',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13, // Increased font back up
                  color: Color(0xFF550000)
                ),
              );
            },
            // Empty cell styling
            cellBuilder: (dateTime) => Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300, width: 0.4),
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Align grlvl to start
          children: [
            topBar(context),
            const SizedBox(height: 10),
            grlvl(), 
            const SizedBox(height: 10),
            timetable(), 
          ],
        ),
      ),
    );
  }
}
