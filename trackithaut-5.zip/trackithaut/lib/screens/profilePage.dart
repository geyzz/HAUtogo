import 'package:flutter/material.dart';
import 'package:trackithaut/screens/about.dart';
import 'package:trackithaut/screens/login.dart';
import 'package:trackithaut/screens/policy.dart';
import 'package:trackithaut/screens/privacySetting.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; // Supabase import

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePage();
}

class _ProfilePage extends State<ProfilePage> {
  // State variables to hold user data
  String _userEmail = 'ffox@student.hau.edu.ph';
  String _userName = 'Loading...'; 

  final TextEditingController controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  // MODIFIED: Function to fetch user data from the 'professors' table
  Future<void> _fetchUserData() async {
    final user = Supabase.instance.client.auth.currentUser;

    if (user != null) {
      // 1. Get the email from the auth session (always available)
      final String userEmail = user.email ?? 'No Email Found';
      _userEmail = userEmail;

      // 2. Fetch the name from the 'professors' table using the email
      try {
        final response = await Supabase.instance.client
            .from('professors') // <-- CORRECT TABLE NAME
            .select('name')        // <-- CORRECT NAME COLUMN
            .eq('email', userEmail)  // <-- Lookup by logged-in user's email
            .single();

        // FIX APPLIED HERE: Removed '&& response != null'
        if (mounted) {
          setState(() {
            // Update the name with the fetched data
            _userName = response['name'] as String? ?? 'User Name Not Found';
          });
        }
      } on PostgrestException catch (e) {
        if (mounted) {
          setState(() {
            _userName = 'Error: Profile Not Found';
          });
        }
        print('Error fetching professor profile: $e');
      } catch (e) {
         if (mounted) {
          setState(() {
            _userName = 'Error Fetching Name';
          });
        }
        print('General error fetching user data: $e');
      }
    } else {
        if (mounted) {
            setState(() {
                _userName = 'Not Logged In';
                _userEmail = 'Please log in';
            });
        }
    }
  }


  Widget topBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 1)),
      ),
      child: Container(
        margin: EdgeInsets.all(10),
        alignment: Alignment.center,
        child: Text(
          'Profile',
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 25,
            fontWeight: FontWeight.w300,
          ),
        ),
      ),
    );
  }

  Widget profile() {
    return Column(
      children: [
        Icon(
          Icons.account_circle,
          size: 90,
        ),
        Text(
          // Use the fetched name here
          _userName, 
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 20,
            fontWeight: FontWeight.w900,
          ),
        ),
        Text(
          // Use the fetched email here
          _userEmail, 
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 12,
            fontWeight: FontWeight.w500,
            decoration: TextDecoration.underline,
          ),
        )
      ],
    );
  }

  Widget settings(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Card(
          //   child: ListTile(
          //     leading: CircleAvatar(
          //       child: Icon(Icons.edit),
          //     ),
          //     title: Text('Edit Profile'),
          //     trailing: Icon(Icons.arrow_forward),
          //     onTap: () {
          //       Navigator.push(
          //         context,
          //         MaterialPageRoute(builder: (context) => EditProfile())
          //       );
          //     },
          //   ),
          // ),
          Container(
            margin: EdgeInsets.only(top: 10, left: 10, bottom: 10),
            child: Text(
              'General Settings',
              style: TextStyle(fontSize: 18),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Icon(Icons.info),
              ),
              title: Text('About'),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => About()),
                );
              },
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Icon(Icons.rule),
              ),
              title: Text('Terms & Conditions'),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Policy()),
                );
              },
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Icon(Icons.privacy_tip),
              ),
              title: Text('Privacy Settings'),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PrivacySetting()),
                );
              },
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 10),
            width: double.maxFinite,
            height: 40,
            child: FilledButton(
              onPressed: () async {
                // Log out logic
                await Supabase.instance.client.auth.signOut();
                
                if (!mounted) return;
                
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Login(),
                  ),
                  (Route<dynamic> route) => false,
                );
              },
              style: FilledButton.styleFrom(
                  backgroundColor: Color(0xFF550000),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                  side: BorderSide(color: Colors.black)),
              child: Text(
                'Log Out',
                style:
                    TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Container(
          child: topBar(context),
        ),
      ),
      body: ListView(
        scrollDirection: Axis.vertical,
        children: [
          Container(
            margin: EdgeInsets.only(left: 40, right: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 25,
                  width: double.infinity,
                ),
                profile(),
                Container(
                  height: 25,
                  width: double.infinity,
                ),
                settings(context),
              ],
            ),
          ),
          Container(
            width: double.maxFinite,
            height: 70,
            alignment: Alignment.center,
          )
        ],
      ),
    );
  }
}