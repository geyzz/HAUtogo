import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
// NOTE: Ensure 'geolocator' is added to your pubspec.yaml
import 'package:geolocator/geolocator.dart'; 
import 'package:trackithaut/screens/login.dart';
import 'package:trackithaut/screens/setNewPass.dart';

// ✅ Global navigator key (lets us navigate outside of BuildContext)
final navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://jhmmrovvjokmebediyzt.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpobW1yb3Z2am9rbWViZWRpeXp0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAxMzUzOTksImV4cCI6MjA3NTcxMTM5OX0.75U7atKYD1CPpZOmp2HsNpjJYEu-Ip1S0YGII875Zls',
  );

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // Existing Supabase subscription
  late final StreamSubscription<AuthState> _authSub;

  // --- LOCATION MONITORING VARIABLES ---
  late StreamSubscription<ServiceStatus> _serviceStatusSubscription;
  bool _isLocationAlertShowing = false;
  // -------------------------------------

  @override
  void initState() {
    super.initState();

    // 1. Setup Location Monitoring
    _checkAndListenLocationService(); 

    // 2. Listen for auth state changes (EXISTING LOGIC)
    _authSub = Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      final event = data.event;
      final session = data.session;
      
      if (event == AuthChangeEvent.passwordRecovery) {
        // Ensure the context is available before navigating
        if (navigatorKey.currentState?.mounted == true) { 
          navigatorKey.currentState?.pushReplacement(
            MaterialPageRoute(
              builder: (_) => SetNewPass(
                email: session?.user.email ?? "",
              ),
            ),
          );
        }
      }
    });
  }

  // --- LOCATION MONITORING METHODS ---

  /// Initial check for location services and setting up the continuous listener.
  void _checkAndListenLocationService() async {
    // 0. Request permission first
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      // Request permission only if it was denied previously
      await Geolocator.requestPermission();
    }
    // We proceed to monitor service status even if permission is denied,
    // as turning on the service is a separate user action.

    // 1. Check initial service status
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // If disabled initially, show the dialog immediately after build is complete
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showLocationDisabledDialog();
      });
    }

    // 2. Start listening for continuous service status changes
    _serviceStatusSubscription =
        Geolocator.getServiceStatusStream().listen((ServiceStatus status) {
      if (status == ServiceStatus.disabled && !_isLocationAlertShowing) {
        // Location service turned OFF while the app is running
        _showLocationDisabledDialog();
      } else if (status == ServiceStatus.enabled && _isLocationAlertShowing) {
        // Location service turned ON, so dismiss the dialog
        final context = navigatorKey.currentContext;
        if (context != null) {
          // Use the global navigator key's context to pop the dialog
          Navigator.of(context, rootNavigator: true).pop();
          _isLocationAlertShowing = false;
        }
      }
    });
  }

  /// Shows a modal dialog that prompts the user to enable location.
  void _showLocationDisabledDialog() {
    final context = navigatorKey.currentContext;

    // Must have a context from the MaterialApp's navigator key to show the dialog
    if (context == null) return; 

    _isLocationAlertShowing = true;
    showDialog(
      context: context,
      // Prevents the dialog from being dismissed by tapping outside or back button
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('📍 Turn on Location'),
          content: const Text(
              'Location services are required. Please enable your device\'s location to continue.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Open Settings'),
              onPressed: () {
                // Takes the user to the location settings
                Geolocator.openLocationSettings();
                // The dialog stays open until the stream detects the location is ON
              },
            ),
          ],
        );
      },
    ).then((_) {
      // This runs if the dialog is dismissed by other means (e.g. back button on Android)
      _isLocationAlertShowing = false;
    });
  }
  // -------------------------------------

  @override
  void dispose() {
    // Cancel both subscriptions to prevent memory leaks
    _authSub.cancel();
    _serviceStatusSubscription.cancel(); 
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey, // ✅ Use global navigator
      home: const Login(),
    );
  }
}