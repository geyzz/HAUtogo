import 'package:flutter/material.dart';
import 'package:trackithaut/screens/mainPage.dart';
import 'forgotPass.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; // Required for login

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _Login();
}

class _Login extends State<Login> {
  // 1. STATE VARIABLES & CONTROLLERS
  var obscureText = true;
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  // 2. LOGIN FUNCTION
  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // Show loading spinner
    if (!mounted) return;
    // NOTE: Using a single Scaffold will make the SnackBar work better than the dialog here, 
    // but keeping the dialog for consistency with the provided code.
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      // On success, remove the loading spinner and navigate
      if (!mounted) return;
      Navigator.pop(context); // remove loading spinner

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const MainPage()),
        (Route<dynamic> route) => false,
      );
    } on AuthException catch (e) {
      if (!mounted) return;
      Navigator.pop(context); // remove loading spinner

      String errorMessage = e.message.contains('Invalid login credentials')
          ? 'Invalid email or password. Please try again.'
          : 'Login failed: ${e.message}';

      // Show error via SnackBar
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(errorMessage),
          backgroundColor: Colors.red,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context); // remove loading spinner

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('An unexpected error occurred: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // 3. WIDGET BUILD (with layout fixes)
  @override
  Widget build(BuildContext context) {
    // 💡 FIX 1: Use Scaffold instead of Material
    return Scaffold(
      // 💡 FIX 2: Set resizeToAvoidBottomInset to false. 
      // This is crucial: it prevents the whole Scaffold body from resizing 
      // when the keyboard appears, allowing the SingleChildScrollView to handle the scroll.
      resizeToAvoidBottomInset: false, 
      body: Stack(
        children: [
          // Background Image and Logo (Top fixed layer)
          Stack(
            children: [
              Image.asset(
                "assets/images/loginbg.jpg",
                height: double.maxFinite,
                fit: BoxFit.cover,
              ),
              Align(
                alignment: const Alignment(0, -0.6), // Use const
                child: Image.asset(
                  "assets/images/logo.png",
                  height: 130,
                  width: 130,
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                ),
              ),
            ],
          ),

          // Login Panel (Bottom section)
          Align(
            alignment: Alignment.bottomCenter,
            // 💡 FIX 3: Wrap the interactive bottom panel in SingleChildScrollView.
            // This allows the panel to scroll up when the keyboard is open, 
            // preventing the overflow error.
            child: SingleChildScrollView( 
              child: Container(
                padding: const EdgeInsets.all(50),
                width: double.infinity,
                // 💡 FIX 4: REMOVE THE FIXED height: 490. 
                // A fixed height prevents the scroll view from working correctly.
                // The inner Column's mainAxisSize: MainAxisSize.min will define the required height.
                // height: 490, 
                decoration: const BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Color(0xFF550000), // Maroon/Red
                      spreadRadius: 10,
                      blurRadius: 0,
                    ),
                    BoxShadow(
                      color: Color(0xFFEFBF04), // Yellow
                      spreadRadius: 5,
                      blurRadius: 0,
                    )
                  ],
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(120),
                    topLeft: Radius.circular(30),
                  ),
                ),
                
                // Form is the first child of the SingleChildScrollView
                child: Form(
                  key: _formKey,
                  child: Column(
                    // Ensures the column only takes up the space needed by its children.
                    mainAxisSize: MainAxisSize.min, 
                    children: [
                      // LOG IN Title
                      Container(
                        margin: const EdgeInsets.only(bottom: 25),
                        child: const Text(
                          'Log In',
                          style: TextStyle(
                              fontSize: 50, fontWeight: FontWeight.bold),
                        ),
                      ),

                      // Email input
                      Container(
                        margin: const EdgeInsets.only(bottom: 15),
                        width: 230,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Email',
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            TextFormField( // Switched to TextFormField for validation
                              controller: emailController,
                              keyboardType: TextInputType.emailAddress,
                              style: const TextStyle(fontSize: 15),
                              decoration: const InputDecoration(
                                filled: true,
                                fillColor: Color(0xFFDFDFDF),
                                border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8)),
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8)),
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                                hintText: 'Enter student email',
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your email';
                                }
                                if (!RegExp(r'^[^@]+@[^@]+\.[^@]+')
                                    .hasMatch(value)) {
                                  return 'Enter a valid email';
                                }
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),

                      // Password input
                      Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        width: 230,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Password',
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            TextFormField( // Switched to TextFormField for validation
                              controller: passwordController,
                              obscureText: obscureText,
                              style: const TextStyle(fontSize: 15),
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: const Color(0xFFDFDFDF),
                                border: const OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8)),
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                                focusedBorder: const OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8)),
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                                hintText: 'Enter password',
                                suffixIcon: IconButton(
                                  onPressed: () {
                                    setState(() {
                                      obscureText = !obscureText;
                                    });
                                  },
                                  icon: Icon(
                                    obscureText
                                        ? Icons.visibility
                                        : Icons.visibility_off,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your password';
                                }
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),

                      // Login button
                      SizedBox(
                        width: 230,
                        height: 40,
                        child: FilledButton(
                          onPressed: _login, // Connect to Supabase login function
                          style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xFF550000), // Red/Maroon
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8)),
                            side: const BorderSide(color: Colors.black),
                          ),
                          child: const Text(
                            'Log In',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                        ),
                      ),

                      // Forgot password button
                      Container(
                        padding: const EdgeInsets.all(10),
                        height: 50,
                        child: TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const ForgotPass(),
                              ),
                            );
                          },
                          child: const Text("Forgot Password?"),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
