import 'package:flutter/material.dart';
import 'package:trackithaut/screens/login.dart';

class SuccessPassUpd extends StatefulWidget {
  const SuccessPassUpd({super.key});

  @override
  State<SuccessPassUpd> createState() => _SuccessPassUpd();
}

class _SuccessPassUpd extends State<SuccessPassUpd> {
  @override
  void initState() {
    super.initState();

    // 🔥 Auto-redirect after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const Login()),
          (Route<dynamic> route) => false,
        );
      }
    });
  }

  Widget passUpd(BuildContext context) {
    return Column(
      children: [
        const Icon(
          Icons.check_circle_outline,
          color: Color(0xFF550000),
          size: 100,
        ),
        Container(
          margin: const EdgeInsets.only(top: 10, bottom: 10),
          child: const Text(
            'Successful Password Update!',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const Text(
          'Your password has been changed.\nClick continue to login.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.normal,
            color: Colors.grey,
          ),
        ),
        Container(
          height: 50,
          width: double.infinity,
          margin: const EdgeInsets.only(top: 20),
          child: FilledButton(
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const Login()),
                (Route<dynamic> route) => false,
              );
            },
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF550000),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text(
              'Continue to Login',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            passUpd(context),
          ],
        ),
      ),
    );
  }
}
