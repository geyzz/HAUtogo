import 'package:flutter/material.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:logger/logger.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';

final logger = Logger();
// --- GEOFENCE CONSTANTS (Holy Angel University, Angeles City) ---
// Approximate coordinates for the center of HAU Campus
const LatLng _campusCenter = LatLng(15.1550, 120.5900);
// Geofence radius in meters (e.g., 500 meters covers the main campus area)
const double _campusRadiusMeters = 500.0;
//

TileLayer get openStreetMapTileLayer => TileLayer(
  urlTemplate: 'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
  userAgentPackageName: 'dev.leaflet.homePage.example',
);

class Professor {
  final String name;
  final String email;
  final String? currentRoom;
  final String? currentBuilding;

  Professor({
    required this.name,
    required this.email,
    this.currentRoom,
    this.currentBuilding,
  });

  factory Professor.fromJson(Map<String, dynamic> json) {
    return Professor(
      name: json['name'] ?? 'Unknown',
      email: json['email'] ?? 'No email',
      currentRoom: json['current_room'] as String?,
      currentBuilding: json['current_building'] as String?,
    );
  }
}

class HomePagee extends StatefulWidget {
  const HomePagee({super.key});
  @override
  State<HomePagee> createState() => _HomePageState();
}

class _HomePageState extends State<HomePagee> {
  // 👇 NEW SUBSCRIPTION VARIABLE FOR REAL-TIME
  late final StreamSubscription<List<Map<String, dynamic>>> _professorsSubscription;
  StreamSubscription<Position>? _positionStreamSubscription;
  Position? _currentPosition;
  bool _isServiceEnabled = true;
  bool _isTracking = false;
  // ----------------------------------------
  List<String> room = [
    '501',
    '502',
    '503',
    '504',
    '505',
    '506',
    '507',
    '508',
    '509',
    '510',
  ];
  List<String> floor = ['1st', '2nd', '3rd', '5th', '6th', '7th'];
  List<String> unibuilding = [
    'St. Joseph Hall Building',
    'Mamerto G. Nepomuceno BUilding',
    'Archbisop Pedro Sanros Building ',
    'St. Joseph Hall Building',
  ];

  int? selectedProfIndex;

  static const double navButtonClosed = 130.0;
  double navButton = navButtonClosed;

  static const double navnextRoomButtonClosed = 65.0;
  double navnextRoomButton = navnextRoomButtonClosed;

  int selectedIndex = 0;
  final PanelController panelController = PanelController();

  final supabase = Supabase.instance.client;
  List<Professor> professors = [];
  String? currentUserEmail; // Store current user's email

  @override
  void initState() {
    super.initState();

    // ⭐ FIX: PERSISTENT LOGIN CHECK
    final session = supabase.auth.currentSession;
    if (session != null) {
      currentUserEmail = session.user.email;
      logger.i('User already logged in: $currentUserEmail');
    } else {
       // If no session, you might redirect to a login screen here
       logger.i('No active session found.');
    }

    // ⭐ REAL-TIME: Set up the subscription instead of a single fetch
    setupProfessorSubscription();
    _checkAndStartLocationTracking();
  }

  @override
  void dispose() {
    _positionStreamSubscription?.cancel();
    _professorsSubscription.cancel(); // ⭐ CANCEL REAL-TIME STREAM
    super.dispose();
  }

  // ⭐ NEW: FUNCTION TO SETUP REAL-TIME SUBSCRIPTION
  void setupProfessorSubscription() {
    if (currentUserEmail == null) {
      // Don't subscribe if we don't know the current user
      return;
    }
    
    // Set up the Real-time listener on the 'professors' table
    _professorsSubscription = supabase
        .from('professors')
        .stream(primaryKey: ['email'])
        .order('name', ascending: true)
        .listen((List<Map<String, dynamic>> data) {
      
      // Map the incoming data to your Professor model and filter out the current user
      final updatedProfessors = data
          .map((p) => Professor.fromJson(p))
          .where((professor) => professor.email != currentUserEmail)
          .toList();

      // Update the UI state
      if (mounted) {
        setState(() {
          professors = updatedProfessors;
        });
      }
      
      logger.i('Real-time professor data updated: ${professors.length}');

    }, onError: (error) {
      logger.e('Error in real-time stream: $error');
    });
  }
  
  // ⭐ NEW: Function to push the location to Supabase (Professor Tracker)
  Future<void> _updateProfessorLocation(String? room, String? building) async {
    final email = supabase.auth.currentUser?.email;
    if (email == null) return;

    try {
      await supabase.from('professors').update({
        'current_room': room,
        'current_building': building,
      }).eq('email', email);
      logger.i('Supabase location updated successfully: $room ($building)');
    } catch (e) {
      logger.e('Error updating Supabase location: $e');
    }
  }


  void _stopLocationTracking() {
    _positionStreamSubscription?.pause(); // Stop the stream if it's running
    setState(() {
      _currentPosition = null; // Clear the current location data
      _isTracking = false; // Set the tracking flag to false
    });
  }

  // 👇 Core geofencing logic - checks if user is within the radius
  bool _isInsideCampus(Position position) {
    double distanceInMeters = Geolocator.distanceBetween(
      _campusCenter.latitude,
      _campusCenter.longitude,
      position.latitude,
      position.longitude,
    );
    return distanceInMeters <= _campusRadiusMeters;
  }

  // 👇 Request permission and start tracking
  Future<void> _checkAndStartLocationTracking() async {
    LocationPermission permission;
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _stopLocationTracking();
        return Future.error('Location permissions are denied');
      }
    }

 if (permission == LocationPermission.deniedForever) {
      _stopLocationTracking();
      await Geolocator.openAppSettings();
      return Future.error(
        'Location permissions are permanently denied, we cannot request permissions.',
      );
    }
    
    // 👇 CORRECT THE TYPO HERE
    // OLD: bool serviceEnabled = await Geolocator.isLocationServiceServiceEnabled();
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      setState(() {
        _isServiceEnabled = false;
      });
      _stopLocationTracking();
      if (mounted) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Location Services Required'),
              content: const Text(
                'Please turn on your phone\'s Location Services (GPS) to use the tracking and campus features.',
              ),
              actions: <Widget>[
                TextButton(
                  child: const Text('OK'),
                  onPressed: () => Navigator.of(context).pop(),
                ),
                TextButton(
                  child: const Text('Open Settings'),
                  onPressed: () async {
                    Navigator.of(context).pop();
                    await Geolocator.openLocationSettings();
                  },
                ),
              ],
            );
          },
        );
      }
      return;
    }
    if (!_isServiceEnabled) {
      setState(() {
        _isServiceEnabled = true;
      });
    }

    // Permissions are granted and service is ON, start tracking.
    _startLocationTracking();
  }

  // 👇 NEW: Start the continuous location stream with geofencing check
  void _startLocationTracking() {
    _positionStreamSubscription?.cancel();

    const locationSettings = LocationSettings(
      accuracy: LocationAccuracy.bestForNavigation,
      distanceFilter: 10, // Update location every 10 meters
    );

    _positionStreamSubscription =
        Geolocator.getPositionStream(
      locationSettings: locationSettings,
    ).listen((Position position) {
      // --- GEOFENCING LOGIC ---
      final bool inside = _isInsideCampus(position);

      if (inside) {
        if (_positionStreamSubscription?.isPaused == true) {
          _positionStreamSubscription?.resume();
        }
        if (mounted) {
          setState(() {
            _currentPosition = position;
            _isTracking = true;
          });
        }
        
        // ⭐ PROFESSOR TRACKER (The Writer): Push live location
        // NOTE: You need to implement your logic to map GPS to a Room/Building here.
        // Using hardcoded values for demonstration until you provide that logic.
        _updateProfessorLocation('501', 'SJH'); 
        
        logger.i(
          'Inside Campus. Lat: ${position.latitude}, Lon: ${position.longitude}',
        );
      } else {
        // --- PAUSE TRACKING WHEN OUTSIDE CAMPUS ---
        _positionStreamSubscription?.pause();
        if (mounted) {
          setState(() {
            _currentPosition = null;
            _isTracking = false;
          });
        }
        
        // ⭐ PROFESSOR TRACKER (The Writer): Clear location
        _updateProfessorLocation(null, null);

        logger.w('Outside Campus. Tracking stopped/paused.');
      }
      // ------------------------------------------
    });

    logger.i('Location tracking started.');
  }

  void openPanel(int index) {
    double pos = panelController.panelPosition;

    if (selectedIndex == index) {
      if (pos == 0.0) {
        panelController.animatePanelToPosition(0.5, curve: Curves.easeInOut);
      } else {
        panelController.close();
      }
    } else {
      setState(() {
        selectedIndex = index;
      });

      if (pos == 0.0) {
        panelController.animatePanelToPosition(0.5, curve: Curves.easeInOut);
      }
    }
  }

  Widget topBar() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Container(
              margin: EdgeInsets.only(right: 10),
              height: 50,
              width: double.maxFinite,
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: Color(0xFF550000),
                borderRadius: BorderRadius.all(Radius.circular(30)),
              ),
              child: Expanded(
                child: Container(
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(30)),
                    color: Colors.white,
                  ),
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      if (_isTracking)
                        Container(
                          margin: const EdgeInsets.only(right: 5),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'Live',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      Text(
                        'HAUtogo',
                        style: TextStyle(
                          color: Color(0xFFEFBF04),
                          fontWeight: FontWeight.w900,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              padding: EdgeInsets.only(top: 5, left: 5, right: 1, bottom: 5),
              height: 50,
              width: double.maxFinite,
              decoration: BoxDecoration(
                color: Color(0xFF550000),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(5),
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      height: 50,
                      margin: EdgeInsets.only(right: 5),
                      alignment: Alignment.center,
                      child: TextField(
                        textAlign: TextAlign.left,
                        style: TextStyle(fontSize: 12),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          hintText: 'Enter Location',
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            borderSide: BorderSide(color: Colors.black),
                          ),
                          border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.black),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    width: 40,
                    height: 40,
                    margin: EdgeInsets.only(right: 5),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(5),
                          bottomLeft: Radius.circular(20),
                          bottomRight: Radius.circular(20),
                        ),
                      ),
                      child: Stack(
                        alignment: Alignment(1, -1),
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.location_on,
                              size: 20,
                              color: Color(0xFFEFBF04),
                            ),
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.location_on_outlined,
                              size: 20,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget building() {
    return Align(
      alignment: Alignment.topLeft,
      child: Container(
        height: 150,
        width: 70,
        decoration: BoxDecoration(
          color: Color(0xFF550000),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(3),
            bottomLeft: Radius.circular(15),
            bottomRight: Radius.circular(15),
          ),
        ),
        margin: EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12),
                  topRight: Radius.circular(1),
                  bottomLeft: Radius.circular(12),
                  bottomRight: Radius.circular(12),
                ),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(1);
                },
                child: Text(
                  'SJH',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(2);
                },
                child: Text(
                  'MGN',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(3);
                },
                child: Text(
                  'APS',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget navNextRoom() {
    return FloatingActionButton.extended(
      backgroundColor: Colors.white,
      onPressed: () {
        openPanel(4);
      },
      label: Text(
        style: TextStyle(
          fontWeight: FontWeight.w900,
          color: Color(0xFFEFBF04),
          fontSize: 15,
        ),
        'Navigate next class',
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(5),
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
    );
  }

  // 👇 mapWidget function to handle geofencing logic
  Widget mapWidget() {
    // Determine the user's location to center the map, or use the campus center as default
    final LatLng center = _currentPosition != null
        ? LatLng(_currentPosition!.latitude, _currentPosition!.longitude)
        : _campusCenter; // Use campus center as default

    // The user marker is only shown if _currentPosition is not null (i.e., inside the geofence)
    final List<Marker> markers = _currentPosition != null
        ? [
            Marker(
              width: 80.0,
              height: 80.0,
              point: LatLng(
                _currentPosition!.latitude,
                _currentPosition!.longitude,
              ),
              child: const Icon(
                Icons.person_pin_circle,
                color: Colors.blue,
                size: 40.0,
              ),
            ),
          ]
        : [];

    return FlutterMap(
      options: MapOptions(
        initialCenter: center,
        initialZoom: 17.0,
        // Ensure the map re-centers on the user's location when updated
        maxZoom: 18.0,
        minZoom: 16.0,
      ),
      children: [
        openStreetMapTileLayer,
        // Show the geofence boundary circle
        CircleLayer(
          circles: [
            CircleMarker(
              point: _campusCenter,
              radius: _campusRadiusMeters,
              color: Color(0xFF550000).withOpacity(0.1),
              borderColor: Color(0xFF550000),
              borderStrokeWidth: 1.0,
            ),
          ],
        ),
        MarkerLayer(markers: markers), // Show marker only when inside campus
      ],
    );
  }

  // 👇 content() REDEFINED to call the new mapWidget
  Widget content() {
    return mapWidget();
  }

  // NOTE: fetchProfessors() was replaced by setupProfessorSubscription() in initState.

  // 👇 UPDATED: Implements the 'Life 360' logic
  Widget prof(BuildContext context) {
    if (professors.isEmpty) {
      return Padding(
        padding: EdgeInsets.all(20),
        child: Center(
          child: Text(
            'No other professors found',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
        ),
      );
    }

    return ListView.builder(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: professors.length,
      itemBuilder: (context, index) {
        final prof = professors[index];
        return Card(
          margin: EdgeInsets.only(bottom: 10),
          child: ListTile(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  prof.name,
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    color: Color(0xFF550000),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  prof.email,
                  style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                ),

                // 👇 START CONDITIONAL LOCATION/SCHEDULE DISPLAY HERE (List View)
                if (_currentPosition != null)
                  // Scenario 1: VIEWER IS INSIDE CAMPUS (Privacy OFF)
                  // Check if the PROFESSOR is actively reporting a room/building
                  if (prof.currentRoom != null && prof.currentBuilding != null)
                    // 1a: Professor is ON CAMPUS and reporting
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(
                        'Current Location: ${prof.currentRoom} (${prof.currentBuilding})',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.green.shade700,
                        ),
                      ),
                    )
                  else
                    // 1b: Professor is NOT REPORTING (Off campus or app closed)
                    const Padding(
                      padding: EdgeInsets.only(top: 4.0),
                      child: Text(
                        'Currently off campus.',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blueGrey,
                        ),
                      ),
                    )
                else
                  // Scenario 2: VIEWER IS OUTSIDE CAMPUS (Privacy ON)
                  // The professor's status is always hidden for security.
                  const Padding(
                    padding: EdgeInsets.only(top: 4.0),
                    child: Text(
                      'Current schedule and location is hidden while off-campus.',
                      style: TextStyle(
                        fontStyle: FontStyle.italic,
                        color: Colors.red,
                      ),
                    ),
                  ),
                // 👆 END CONDITIONAL DISPLAY
              ],
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            onTap: () {
              setState(() {
                selectedProfIndex = index;
                selectedIndex = 5;
              });
            },
          ),
        );
      },
    );
  }

  Widget sjh() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image of St. Joseph Hall Building
          Container(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              color: Colors.transparent,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/joseph_hall.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),

          // Building name
          Container(
            margin: EdgeInsets.only(left: 30),
            child: Text(
              'St. Joseph Hall Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          // Professors header
          Container(
            margin: EdgeInsets.only(top: 20),
            color: Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: Alignment(0, 0),
            child: Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          // Professors list
          Container(margin: EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  Widget mgn() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/mgn.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),

          Container(
            margin: EdgeInsets.only(left: 30),
            child: Text(
              'Mamerto G. Nepomuceno Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20),
            color: Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: Alignment(0, 0),
            child: Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(margin: EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  Widget aps() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/aps.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),

          Container(
            margin: EdgeInsets.only(left: 30),
            child: Text(
              'Archbisop Pedro Sanros Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20),
            color: Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: Alignment(0, 0),
            child: Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(margin: EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  Widget navNextRoompanel() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.only(left: 10),
            child: Text(
              'Location:',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 40),
            child: Text(
              'Floor: ${floor[2]} floor\nRoom: ${room[2]}\nBuilding: ${unibuilding[2]}',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20),
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 119, 119, 119),
            ),
            width: double.infinity,
            height: 280,
            alignment: Alignment.center,
            child: Image.asset(
              'assets/images/myimage.png',
              errorBuilder: (context, error, stackTrace) {
                return Image.asset('assets/images/placeholder.png');
              },
            ),
          ),
        ],
      ),
    );
  }

  // 👇 CORRECTED: Hides location/floor if viewer is off-campus
  Widget navProfpanel(int index) {
    final prof = professors[index];

    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: const Color(0xFF550000),
            height: 60,
            width: double.infinity,
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Professor ${prof.name}',
                  style: const TextStyle(
                    fontSize: 20,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  prof.email,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),

          // --- CONDITIONAL LOCATION DISPLAY (Detail View) ---
          if (_currentPosition != null) // If VIEWER IS INSIDE CAMPUS
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(left: 40, top: 20),
                  child: Text(
                    // NOTE: Use prof.currentRoom and prof.currentBuilding when available from the database
                    'Floor: ${floor[index]} floor\nRoom: ${room[index]}\nBuilding: ${unibuilding[index]}',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF550000),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 119, 119, 119),
                  ),
                  width: double.infinity,
                  height: 280,
                  alignment: Alignment.center,
                  child: Image.asset(
                    'assets/images/myimage.png',
                    errorBuilder: (context, error, stackTrace) {
                      return Image.asset('assets/images/placeholder.png');
                    },
                  ),
                ),
              ],
            )
          else // If VIEWER IS OUTSIDE CAMPUS, show privacy message instead of location details
            Container(
              margin: EdgeInsets.all(40),
              child: const Center(
                child: Text(
                  'Professor\'s schedule and location is hidden while off-campus for privacy.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontStyle: FontStyle.italic,
                    color: Colors.red,
                  ),
                ),
              ),
            ),
          // --- END CONDITIONAL LOCATION DISPLAY ---
        ],
      ),
    );
  }

  // 👇 CORRECTED: Removed the status bar from the final return block
  Widget panelContent() {
    // 1. CHECK FOR LOCATION SERVICE DISABLED (Highest Priority)
    if (!_isServiceEnabled) {
      return Column(
        children: [
          // Display the specific "Services Disabled" status
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'Location Status: ⚠️ Location Services Disabled', // Explicit warning text
              style: TextStyle(
                color: Colors.orange.shade800,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 10),
          const Padding(
            padding: EdgeInsets.all(20.0),
            child: Text(
              'Please enable your phone\'s Location Services (GPS) to use campus features.',
              textAlign: TextAlign.center,
              style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
            ),
          ),
        ],
      );
    }

    // 2. NORMAL CONTENT (Services are enabled)
    Widget mainContent;

    switch (selectedIndex) {
      case 1:
        mainContent = sjh();
        break;
      case 2:
        mainContent = mgn();
        break;
      case 3:
        mainContent = aps();
        break;
      case 4:
        mainContent = navNextRoompanel();
        break;
      case 5:
        // Professor detail view after clicking a name
        if (!panelController.isPanelOpen) {
          panelController.animatePanelToPosition(0.5);
        }
        int index = selectedProfIndex ?? 0;
        if (professors.isNotEmpty && index < professors.length) {
          mainContent = navProfpanel(index);
        } else {
          mainContent = const Center(
            child: Text('Professor data not available.'),
          );
        }
        break;
      default:
        // Default view: Show the list of all professors
        mainContent = Column(
          children: [
            const Padding(
              padding: EdgeInsets.only(top: 10, bottom: 5),
              child: Text(
                'ALL PROFESSORS',
                style: TextStyle(
                  fontSize: 20,
                  color: Color(0xFF550000),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Container(margin: EdgeInsets.all(20), child: prof(context)),
          ],
        );
        break;
    }

    // 3. FINAL RETURN BLOCK: Only returns the main content, no status bar.
    return Column(
      children: [
        const SizedBox(height: 10),
        mainContent, // The professor/building content
      ],
    );
  }

  Widget buildNavButton(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Colors.white,
      child: Icon(Icons.my_location, color: Color(0xFFEFBF04)),
      onPressed: () {},
    );
  }

  Widget toggleButton() {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        Container(
          alignment: Alignment.center,
          width: double.maxFinite,
          height: 30,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            color: Color(0xFF550000),
          ),
        ),
        Container(
          alignment: Alignment.center,
          margin: EdgeInsets.all(10),
          width: 50,
          height: 5,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Color(0xFFEFBF04),
          ),
        ),
      ],
    );
  }

  final ScrollController _controller = ScrollController();

  Widget panelWidget() {
    return Column(
      children: [
        toggleButton(),
        Expanded(
          child: ListView(
            padding: EdgeInsets.zero,
            controller: _controller,
            children: <Widget>[panelContent(), SizedBox(height: 60)],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    double panelHeightOpen = 620;
    final panelHeightClosed = MediaQuery.of(context).size.height * 0;

    return Scaffold(
      body: Stack(
        alignment: Alignment.topCenter,
        children: <Widget>[
          content(),
          Stack(
            children: [
              Container(
                margin: EdgeInsets.only(top: 40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [topBar(), building()],
                ),
              ),
            ],
          ),
          SlidingUpPanel(
            borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            controller: panelController,
            maxHeight: panelHeightOpen,
            minHeight: panelHeightClosed,
            panelBuilder: (ScrollController sc) {
              return Column(
                children: [
                  toggleButton(),
                  Expanded(
                    child: ListView(
                      padding: EdgeInsets.zero,
                      controller: sc,
                      children: <Widget>[panelContent(), SizedBox(height: 60)],
                    ),
                  ),
                ],
              );
            },
            snapPoint: 0.5,
            onPanelSlide: (position) => setState(() {
              double panelMaxScrollExtent = panelHeightOpen;
              navButton =
                  navButtonClosed + (panelMaxScrollExtent - 50) * position;
              navnextRoomButton =
                  navnextRoomButtonClosed +
                  (panelMaxScrollExtent - 50) * position;
            }),
          ),
          Positioned(
            bottom: navButton,
            right: 20,
            child: Column(children: [buildNavButton(context)]),
          ),
          Positioned(
            bottom: navnextRoomButton,
            right: 20,
            child: Column(children: [navNextRoom()]),
          ),
        ],
      ),
    );
  }
}