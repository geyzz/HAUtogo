import 'package:flutter/material.dart';
import 'package:trackithaut/screens/changePass.dart';

class PrivacySetting extends StatefulWidget {
  const PrivacySetting({super.key});

  @override
  State<PrivacySetting> createState() => _PrivacySettingState();
}

class _PrivacySettingState extends State<PrivacySetting> {
  bool locationEnabled = false;

  Widget buildSettingsList(BuildContext context) {
    return Column(
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.location_on),
            title: const Text('Location Permission'),
            trailing: Switch(
              value: locationEnabled,
              activeColor: const Color(0xFF550000),
              onChanged: (bool value) {
                setState(() {
                  locationEnabled = value;
                });
              },
            ),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.lock_open),
            title: const Text('Change Password'),
            trailing: const Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ChangePass()),
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Privacy Settings',
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 22,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: buildSettingsList(context),
      ),
    );
  }
}
