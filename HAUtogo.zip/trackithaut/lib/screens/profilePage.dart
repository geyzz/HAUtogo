import 'package:flutter/material.dart';
import 'package:trackithaut/screens/about.dart';
import 'package:trackithaut/screens/login.dart';
import 'package:trackithaut/screens/policy.dart';
import 'package:trackithaut/screens/privacySetting.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePage();
}

class _ProfilePage extends State<ProfilePage> {
  String _userEmail = 'Loading...';
  String _userName = 'Loading...';
  String _userRole = ''; // new field to know if student or professor

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  /// Fetch user profile — first try professors, then students.
  Future<void> _fetchUserData() async {
    final user = Supabase.instance.client.auth.currentUser;

    if (user == null) {
      if (mounted) {
        setState(() {
          _userEmail = 'Please log in';
          _userName = 'Not Logged In';
          _userRole = '';
        });
      }
      return;
    }

    final userEmail = user.email ?? 'No Email Found';

    try {
      // 🔹 Try professors table first
      final profResponse = await Supabase.instance.client
          .from('professors')
          .select('name')
          .eq('email', userEmail)
          .maybeSingle();

      if (profResponse != null) {
        if (mounted) {
          setState(() {
            _userEmail = userEmail;
            _userName = profResponse['name'] ?? 'Professor';
            _userRole = 'Professor';
          });
        }
        return;
      }

      // 🔹 If not found, try students table
      final studentResponse = await Supabase.instance.client
          .from('students')
          .select('name')
          .eq('email', userEmail)
          .maybeSingle();

      if (studentResponse != null) {
        if (mounted) {
          setState(() {
            _userEmail = userEmail;
            _userName = studentResponse['name'] ?? 'Student';
            _userRole = 'Student';
          });
        }
        return;
      }

      // 🔹 No matching record in either table
      if (mounted) {
        setState(() {
          _userEmail = userEmail;
          _userName = 'User Not Found in Database';
          _userRole = '';
        });
      }
    } on PostgrestException catch (e) {
      print('Database error: $e');
      if (mounted) {
        setState(() {
          _userEmail = userEmail;
          _userName = 'Error Loading Profile';
          _userRole = '';
        });
      }
    } catch (e) {
      print('General error: $e');
      if (mounted) {
        setState(() {
          _userEmail = userEmail;
          _userName = 'Unexpected Error';
          _userRole = '';
        });
      }
    }
  }

  Widget topBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 1)),
      ),
      child: Container(
        margin: const EdgeInsets.all(10),
        alignment: Alignment.center,
        child: const Text(
          'Profile',
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 25,
            fontWeight: FontWeight.w300,
          ),
        ),
      ),
    );
  }

  Widget profile() {
    return Column(
      children: [
        const Icon(
          Icons.account_circle,
          size: 90,
          color: Color(0xFF550000),
        ),
        Text(
          _userName,
          style: const TextStyle(
            color: Color(0xFF550000),
            fontSize: 20,
            fontWeight: FontWeight.w900,
          ),
        ),
        Text(
          _userEmail,
          style: const TextStyle(
            color: Color(0xFF550000),
            fontSize: 12,
            fontWeight: FontWeight.w500,
            decoration: TextDecoration.underline,
          ),
        ),
        if (_userRole.isNotEmpty)
          Text(
            _userRole,
            style: const TextStyle(
              color: Colors.grey,
              fontSize: 12,
              fontStyle: FontStyle.italic,
            ),
          ),
      ],
    );
  }

  Widget settings(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 10, left: 10, bottom: 10),
            child: const Text(
              'General Settings',
              style: TextStyle(fontSize: 18),
            ),
          ),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.info)),
              title: const Text('About'),
              trailing: const Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const About()),
                );
              },
            ),
          ),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.rule)),
              title: const Text('Terms & Conditions'),
              trailing: const Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Policy()),
                );
              },
            ),
          ),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.privacy_tip)),
              title: const Text('Privacy Settings'),
              trailing: const Icon(Icons.arrow_forward),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PrivacySetting()),
                );
              },
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 10),
            width: double.maxFinite,
            height: 40,
            child: FilledButton(
              onPressed: () async {
                await Supabase.instance.client.auth.signOut();
                if (!mounted) return;
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const Login()),
                  (route) => false,
                );
              },
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF550000),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                side: const BorderSide(color: Colors.black),
              ),
              child: const Text(
                'Log Out',
                style:
                    TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: topBar(context)),
      body: ListView(
        children: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 40),
            child: Column(
              children: [
                const SizedBox(height: 25),
                profile(),
                const SizedBox(height: 25),
                settings(context),
              ],
            ),
          ),
          const SizedBox(height: 70),
        ],
      ),
    );
  }
}
