package com.example.trackithaut

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
